<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://selise.ch/
 * @since      1.0.0
 *
 * @package    Lankabangla_Transactions
 * @subpackage Lankabangla_Transactions/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Lankabangla_Transactions
 * @subpackage Lankabangla_Transactions/includes
 * @author     Selise Team (ITSM) <rabiul.islam@selise.ch>
 */
class Lankabangla_Transactions_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
