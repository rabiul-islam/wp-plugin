<?php

/**
* The plugin bootstrap file
*
* This file is read by WordPress to generate the plugin information in the plugin
* admin area. This file also includes all of the dependencies used by the plugin,
* registers the activation and deactivation functions, and defines a function
* that starts the plugin.
*
* @link              http://selise.ch/
* @since             1.0.0
* @package           Lankabangla_Transactions
*
* @wordpress-plugin
* Plugin Name:       Lankabangla Transactions
* Plugin URI:        http://selise.ch/
* Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
* Version:           1.0.0
* Author:            Selise Team (ITSM)
* Author URI:        http://selise.ch/
* License:           GPL-2.0+
* License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
* Text Domain:       lankabangla-transactions
* Domain Path:       /languages
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
   die;
}

/**
* Currently plugin version.
* Start at version 1.0.0 and use SemVer - https://semver.org
* Rename this for your plugin and update it as you release new versions.
*/
define( 'LANKABANGLA_TRANSACTIONS_VERSION', '1.0.0' );

/**
* The code that runs during plugin activation.
* This action is documented in includes/class-lankabangla-transactions-activator.php
*/
function activate_lankabangla_transactions() {
   require_once plugin_dir_path( __FILE__ ) . 'includes/class-lankabangla-transactions-activator.php';
   Lankabangla_Transactions_Activator::activate();
}

/**
* The code that runs during plugin deactivation.
* This action is documented in includes/class-lankabangla-transactions-deactivator.php
*/
function deactivate_lankabangla_transactions() {
   require_once plugin_dir_path( __FILE__ ) . 'includes/class-lankabangla-transactions-deactivator.php';
   Lankabangla_Transactions_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_lankabangla_transactions' );
register_deactivation_hook( __FILE__, 'deactivate_lankabangla_transactions' );

/**
* The core plugin class that is used to define internationalization,
* admin-specific hooks, and public-facing site hooks.
*/
require plugin_dir_path( __FILE__ ) . 'includes/class-lankabangla-transactions.php';
 
 


/**
* Begins execution of the plugin.
*
* Since everything within the plugin is registered via hooks,
* then kicking off the plugin from this point in the file does
* not affect the page life cycle.
*
* @since    1.0.0
*/



 
//ajax add action
add_action('wp_ajax_nopriv_selection_ajax_function_callback', 'selection_ajax_function_callback'); 
add_action('wp_ajax_selection_ajax_function_callback', 'selection_ajax_function_callback');



//ajax data
function selection_ajax_function_callback(){   
 //echo 'search query'; 
    $yearsSelector =  $_REQUEST['yearsSelector'];
   $sectorsSelector = $_REQUEST['sectorsSelector'];

   $args = array(
      'post_type' => 'transactions',
      'posts_per_page'=> -1,
      'tax_query' => array(
         'relation' => 'OR',
         array(
            'taxonomy' => 'transactions_sectors',
            'field'    => 'slug',
            'terms'    => $sectorsSelector,
         ),
         array(
            'taxonomy' => 'transactions_years',
            'field'    => 'slug',
            'terms'    => $yearsSelector,
         ),
      ),
   );

   $search_query = new WP_Query( $args);

   if( $search_query->have_posts() ) {

      while( $search_query->have_posts() ) {
         $search_query->the_post();

         $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumbnail' );  
          
         $terms = wp_get_object_terms( get_the_ID(), 'transactions_category');

         foreach($terms as $cat){
            $cat_slug_by_post_id = $cat->slug;
         } 

         ?>

         <div id="post_inner" class="post_inner_search col-md-4">
            <img src="<?php echo $image[0]; ?>" width="100" alt="<?php the_title();?>">
            <div class="post_details"> 
               <a href="<?php the_permalink(); ?>" title="<?php the_title();?>"><?php the_title(); ?></a>
               <p><?php the_content();?></p>
               <p><?php the_excerpt(); ?></p>
            </div>
         </div> 
         <?php
      }
   }

   die(); 
}

add_shortcode( 'transactions_shortcode', 'transactions_shortcode_func' );
function transactions_shortcode_func() { 
 
   require plugin_dir_path( __FILE__ ) . 'public/partials/lankabangla-transactions-public-display.php';
    
}
    


function run_lankabangla_transactions() {
   $plugin = new Lankabangla_Transactions();
   $plugin->run();
}
run_lankabangla_transactions();