(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */ 
	 
jQuery("#FormId").submit(function(event){
    event.preventDefault(); 
   
    var years_selector = jQuery(".InputGroup input[name='years_selector']:checked").val();
    var sectors_selector = jQuery(".InputGroup input[name='sectors_selector']:checked").val(); 
 
    
    if((typeof years_selector === "undefined") && ( typeof sectors_selector === "undefined")){
      jQuery(".select_alert").show().fadeIn(14000).fadeOut(3000);  
    }else{
    jQuery.ajax({ 
      url: search_ajax.ajax_url, //did not same function wordpress such as ajax_url
      type: "POST", 
      data: {
        action:"selection_ajax_function_callback",
        yearsSelector: years_selector,
        sectorsSelector: sectors_selector
      },
      beforeSend: function(){ 
        jQuery(".spinner").show(); 
      }, success: function(response){
        //console.log(response);
        jQuery(".spinner").hide(); 
        jQuery(".mix").hide();
        jQuery(".post_inner_search").hide();
        jQuery("#year_sectors_modal .close").click();
        
        jQuery("#results").prepend(response); 
      }
  
     });
    }



});  



//custom open modal
 jQuery('.open_modal').click(function(){  
    jQuery("#year_sectors_modal").modal('show');
});

 //when clicking button search others data hide
 jQuery('.controls button').click(function(){  
    var cat_name = jQuery(this).attr('data-filter');  
    if(cat_name == 'all'){
         jQuery(".mix").show();
    }else{
        var  cat = cat_name.split("."); 
        jQuery("."+cat[1]).show(); 
    }
    jQuery(".post_inner_search").hide();
  })
  

})( jQuery );