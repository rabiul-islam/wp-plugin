<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://selise.ch/
 * @since      1.0.0
 *
 * @package    Lankabangla_Transactions
 * @subpackage Lankabangla_Transactions/public/partials
 */
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="transaction_wrapper">
    <div class="container">
        <div class="row"> 
        <div class="mixitup_inner">
           <div class="controls">
            <button type="button" class="control" data-filter="all">All</button>
            <?php
            $cat_args=array( 
                'taxonomy' => 'transactions_category',
                'hierarchical' => 0, 
                'orderby' => 'term_id',
                'order'  => 'ASC'

            );
            $categories = get_categories($cat_args);

            foreach ($categories as $key=>$category) {
                 //echo '<pre>'; print_r($category); echo '</pre>';

                ?>

            <button type="button" class="control" data-filter=".<?php echo $category->slug; ?>"><?php echo $category->name; ?></button>
                <?php
            }
            ?> 
        <div class="filter_panel">
            <div class="open_modal">Filter by: <strong >Year/Sector</strong></div>
        </div> 


        <div class="container" data-ref="containers">
            <div class="row" id="results">
            <?php

            $args = array(      
                'post_type' => 'transactions',
                'post_status' => 'publish', 
                'order' => 'ASC',                 
            );

            $post = new WP_Query($args); 
            while ( $post->have_posts() ) : $post->the_post(); 
                // echo '<pre>'; print_r($query); echo '</pre>'; 
                // get the medium-sized image url 
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );   

             
            $terms = wp_get_object_terms( get_the_ID(), 'transactions_category' );

           
            foreach($terms as $cat){
                $cat_slug_by_post_id = $cat->slug;
            }  
            ?>   
            <div  id="post_inner" data-slug="<?php echo $cat_slug_by_post_id; ?>" class="col-md-4 mix <?php echo $cat_slug_by_post_id; ?>" data-size="1">

                <img src="<?php echo $image[0]; ?>" alt="<?php the_title();?>">
                <div class="post_details"> 
                    <a href="#" title="<?php the_title();?>"><?php the_title(); ?></a>
                    <?php the_content(); ?>
                    <p class="lnk-excerpt"><?php echo lnkb_kses(get_the_excerpt()); ?></p>
                </div>
            </div> 

        <?php 
        endwhile; 
        wp_reset_query(); 
         ?>

            <div class="gap"></div>
            <div class="gap"></div>
            <div class="gap"></div>
        </div>
      </div>
    </div><!-- mixitup inner-->
    </div><!-- row-->
</div><!-- container-->
</div>

 
 <!-- Modal Html-->
<div class="modal fade" id="year_sectors_modal" >
  <div class="modal-dialog modal-lg">
    <form method="post" id="FormId">
      <div class="modal-content">
        <button type="button" class="close text-right modal_close_btn" data-dismiss="modal" aria-hidden="true">×</button> 

        <div class="search_list_inner"> 

          <div class="alert alert-danger select_alert" role="alert">
            Please select at least one years/sectors
          </div>
          <h3>Year</h3> 

          <div class="InputGroup years"> 
            <?php
            $trans_years_args =array( 
              'taxonomy' => 'transactions_years',
              'hierarchical' => 0, 
              'orderby' => 'term_id',
              'order'  => 'DESC'
            );
            $trans_years_query = get_categories($trans_years_args);
            foreach ($trans_years_query as $key=>$years) { ?>                 
              <input type="radio" name="years_selector" id="<?php echo $years->slug; ?>" value="<?php echo $years->slug; ?>">
              <label for="<?php echo $years->slug; ?>"><?php echo $years->name; ?></label> 
              <?php
            }
            ?>   
          </div>  
        </div>


        <div class="search_list_inner">
          <h3>Sectors</h3>
          <div class="InputGroup sectors"> 
            <?php
            $trans_sectors_args =array( 
              'taxonomy' => 'transactions_sectors',
              'hierarchical' => 0, 
              'orderby' => 'term_id',
              'order'  => 'DESC'
            );
            $trans_sectors_query = get_categories($trans_sectors_args);
            foreach ($trans_sectors_query as $key=>$sectors) {?>                  
              <input type="radio" name="sectors_selector" id="<?php echo $sectors->slug; ?>" value="<?php echo $sectors->slug; ?>">
              <label for="<?php echo $sectors->slug; ?>"><?php echo $sectors->name; ?></label> 
            <?php } ?>
          </div>

        </div>

        <div class="btn_area">
          <div class="align-items-center spinner">             
            <div class="spinner-border ml-auto" role="status" aria-hidden="true"></div>
          </div>
          <input type="submit" name="submit_btn" class="submit_btn btn btn-secondary" value="Submit">
          <input type="Reset" class="btn btn-primary" name="Reset_btn" value="Reset">
        </div>

      </div>
    </form>
  </div>
</div>
<!--modal html close-->
<script>
    //mixitup core git
    var containers = document.querySelector('[data-ref="containers"]');
    var mixer = mixitup(containers, { 
        animation: {
            duration: 350
        }
    });
</script>
 
 <!---main js load after html-->
 <script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/plugins/lankabangla-transactions/public/js/lankabangla-transactions-public.js"></script>